/*
 * SWGLocation.h
 * 
 * 
 */

#ifndef SWGLocation_H_
#define SWGLocation_H_

#include <QJsonObject>


#include "SWGNumber.h"

#include "SWGObject.h"


namespace Swagger {

class SWGLocation: public SWGObject {
public:
    SWGLocation();
    SWGLocation(QString* json);
    virtual ~SWGLocation();
    void init();
    void cleanup();

    QString asJson ();
    QJsonObject* asJsonObject();
    void fromJsonObject(QJsonObject &json);
    SWGLocation* fromJson(QString &jsonString);

    SWGNumber* getLat();
    void setLat(SWGNumber* lat);
    SWGNumber* getLng();
    void setLng(SWGNumber* lng);
    

private:
    SWGNumber* lat;
    SWGNumber* lng;
    
};

} /* namespace Swagger */

#endif /* SWGLocation_H_ */
