
#include "SWGLocation.h"

#include "SWGHelpers.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QObject>
#include <QDebug>

namespace Swagger {


SWGLocation::SWGLocation(QString* json) {
    init();
    this->fromJson(*json);
}

SWGLocation::SWGLocation() {
    init();
}

SWGLocation::~SWGLocation() {
    this->cleanup();
}

void
SWGLocation::init() {
    lat = 0.0;
    lng = 0.0;
    
}

void
SWGLocation::cleanup() {
    if(lat != NULL) {
        delete lat;
    }
    if(lng != NULL) {
        delete lng;
    }
    
}

SWGLocation*
SWGLocation::fromJson(QString &json) {
    QByteArray array (json.toStdString().c_str());
    QJsonDocument doc = QJsonDocument::fromJson(array);
    QJsonObject jsonObject = doc.object();
    this->fromJsonObject(jsonObject);
    return this;
}

void
SWGLocation::fromJsonObject(QJsonObject &pJson) {
    setValue(&lat, pJson["lat"], "SWGNumber", "SWGNumber");
    setValue(&lng, pJson["lng"], "SWGNumber", "SWGNumber");
    
}

QString
SWGLocation::asJson ()
{
    QJsonObject* obj = this->asJsonObject();
    
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    return QString(bytes);
}

QJsonObject*
SWGLocation::asJsonObject() {
    QJsonObject* obj = new QJsonObject();
    
    
    toJsonValue(QString("lat"), lat, obj, QString("SWGNumber"));
    
    
    
    
    
    toJsonValue(QString("lng"), lng, obj, QString("SWGNumber"));
    
    
    
    

    return obj;
}

SWGNumber*
SWGLocation::getLat() {
    return lat;
}
void
SWGLocation::setLat(SWGNumber* lat) {
    this->lat = lat;
}

SWGNumber*
SWGLocation::getLng() {
    return lng;
}
void
SWGLocation::setLng(SWGNumber* lng) {
    this->lng = lng;
}



} /* namespace Swagger */

