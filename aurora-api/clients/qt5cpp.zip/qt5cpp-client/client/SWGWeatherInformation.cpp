
#include "SWGWeatherInformation.h"

#include "SWGHelpers.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QObject>
#include <QDebug>

namespace Swagger {


SWGWeatherInformation::SWGWeatherInformation(QString* json) {
    init();
    this->fromJson(*json);
}

SWGWeatherInformation::SWGWeatherInformation() {
    init();
}

SWGWeatherInformation::~SWGWeatherInformation() {
    this->cleanup();
}

void
SWGWeatherInformation::init() {
    summary = new QString("");
    
}

void
SWGWeatherInformation::cleanup() {
    if(summary != NULL) {
        delete summary;
    }
    
}

SWGWeatherInformation*
SWGWeatherInformation::fromJson(QString &json) {
    QByteArray array (json.toStdString().c_str());
    QJsonDocument doc = QJsonDocument::fromJson(array);
    QJsonObject jsonObject = doc.object();
    this->fromJsonObject(jsonObject);
    return this;
}

void
SWGWeatherInformation::fromJsonObject(QJsonObject &pJson) {
    setValue(&summary, pJson["summary"], "QString", "QString");
    
}

QString
SWGWeatherInformation::asJson ()
{
    QJsonObject* obj = this->asJsonObject();
    
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    return QString(bytes);
}

QJsonObject*
SWGWeatherInformation::asJsonObject() {
    QJsonObject* obj = new QJsonObject();
    
    
    toJsonValue(QString("summary"), summary, obj, QString("QString"));
    
    
    
    

    return obj;
}

QString*
SWGWeatherInformation::getSummary() {
    return summary;
}
void
SWGWeatherInformation::setSummary(QString* summary) {
    this->summary = summary;
}



} /* namespace Swagger */

