
#include "SWGGeomagnaticLocation.h"

#include "SWGHelpers.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QObject>
#include <QDebug>

namespace Swagger {


SWGGeomagnaticLocation::SWGGeomagnaticLocation(QString* json) {
    init();
    this->fromJson(*json);
}

SWGGeomagnaticLocation::SWGGeomagnaticLocation() {
    init();
}

SWGGeomagnaticLocation::~SWGGeomagnaticLocation() {
    this->cleanup();
}

void
SWGGeomagnaticLocation::init() {
    latG = 0.0;
    lngG = 0.0;
    
}

void
SWGGeomagnaticLocation::cleanup() {
    if(latG != NULL) {
        delete latG;
    }
    if(lngG != NULL) {
        delete lngG;
    }
    
}

SWGGeomagnaticLocation*
SWGGeomagnaticLocation::fromJson(QString &json) {
    QByteArray array (json.toStdString().c_str());
    QJsonDocument doc = QJsonDocument::fromJson(array);
    QJsonObject jsonObject = doc.object();
    this->fromJsonObject(jsonObject);
    return this;
}

void
SWGGeomagnaticLocation::fromJsonObject(QJsonObject &pJson) {
    setValue(&latG, pJson["latG"], "SWGNumber", "SWGNumber");
    setValue(&lngG, pJson["lngG"], "SWGNumber", "SWGNumber");
    
}

QString
SWGGeomagnaticLocation::asJson ()
{
    QJsonObject* obj = this->asJsonObject();
    
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    return QString(bytes);
}

QJsonObject*
SWGGeomagnaticLocation::asJsonObject() {
    QJsonObject* obj = new QJsonObject();
    
    
    toJsonValue(QString("latG"), latG, obj, QString("SWGNumber"));
    
    
    
    
    
    toJsonValue(QString("lngG"), lngG, obj, QString("SWGNumber"));
    
    
    
    

    return obj;
}

SWGNumber*
SWGGeomagnaticLocation::getLatG() {
    return latG;
}
void
SWGGeomagnaticLocation::setLatG(SWGNumber* latG) {
    this->latG = latG;
}

SWGNumber*
SWGGeomagnaticLocation::getLngG() {
    return lngG;
}
void
SWGGeomagnaticLocation::setLngG(SWGNumber* lngG) {
    this->lngG = lngG;
}



} /* namespace Swagger */

