/*
 * SWGGeomagnaticLocation.h
 * 
 * 
 */

#ifndef SWGGeomagnaticLocation_H_
#define SWGGeomagnaticLocation_H_

#include <QJsonObject>


#include "SWGNumber.h"

#include "SWGObject.h"


namespace Swagger {

class SWGGeomagnaticLocation: public SWGObject {
public:
    SWGGeomagnaticLocation();
    SWGGeomagnaticLocation(QString* json);
    virtual ~SWGGeomagnaticLocation();
    void init();
    void cleanup();

    QString asJson ();
    QJsonObject* asJsonObject();
    void fromJsonObject(QJsonObject &json);
    SWGGeomagnaticLocation* fromJson(QString &jsonString);

    SWGNumber* getLatG();
    void setLatG(SWGNumber* latG);
    SWGNumber* getLngG();
    void setLngG(SWGNumber* lngG);
    

private:
    SWGNumber* latG;
    SWGNumber* lngG;
    
};

} /* namespace Swagger */

#endif /* SWGGeomagnaticLocation_H_ */
