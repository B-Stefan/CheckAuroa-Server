/*
 * SWGWeatherInformation.h
 * 
 * 
 */

#ifndef SWGWeatherInformation_H_
#define SWGWeatherInformation_H_

#include <QJsonObject>


#include <QString>

#include "SWGObject.h"


namespace Swagger {

class SWGWeatherInformation: public SWGObject {
public:
    SWGWeatherInformation();
    SWGWeatherInformation(QString* json);
    virtual ~SWGWeatherInformation();
    void init();
    void cleanup();

    QString asJson ();
    QJsonObject* asJsonObject();
    void fromJsonObject(QJsonObject &json);
    SWGWeatherInformation* fromJson(QString &jsonString);

    QString* getSummary();
    void setSummary(QString* summary);
    

private:
    QString* summary;
    
};

} /* namespace Swagger */

#endif /* SWGWeatherInformation_H_ */
