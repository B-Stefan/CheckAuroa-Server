/// <reference path="api.d.ts" />

module API.Client {
    'use strict';

    export class WeatherInformation {

        summary: string;
    }

}