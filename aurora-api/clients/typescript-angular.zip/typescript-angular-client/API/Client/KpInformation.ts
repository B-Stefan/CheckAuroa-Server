/// <reference path="api.d.ts" />

module API.Client {
    'use strict';

    export class KpInformation {

        utc: number;

        date: Date;

        kpValue: number;
    }

}