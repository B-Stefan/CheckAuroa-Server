/// <reference path="api.d.ts" />

module API.Client {
    'use strict';

    export class Error {

        msg: string;

        /**
         * The error code
         */
        code: Error.CodeEnum;
    }

    export module Error {

        export enum CodeEnum {  
            INTERNAL = <any> 'INTERNAL', 
            KP_SERVICE_ERROR = <any> 'KP_SERVICE_ERROR', 
            WEATHER_SERVICE_ERROR = <any> 'WEATHER_SERVICE_ERROR', 
            SUNSETRISE_SERVICE_ERROR = <any> 'SUNSETRISE_SERVICE_ERROR',
        }
    }
}