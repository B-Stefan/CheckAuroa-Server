/// <reference path="api.d.ts" />

module API.Client {
    'use strict';

    export class GeomagnaticLocation {

        latG: number;

        lngG: number;
    }

}