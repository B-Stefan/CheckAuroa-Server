/// <reference path="api.d.ts" />

module API.Client {
    'use strict';

    export class Rating {

        location: Location;

        locationGeomagnatic: GeomagnaticLocation;

        kp: KpInformation;

        weather: WeatherInformation;
    }

}