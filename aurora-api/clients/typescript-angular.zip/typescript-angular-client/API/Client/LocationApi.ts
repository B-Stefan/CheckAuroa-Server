/// <reference path="api.d.ts" />

/* tslint:disable:no-unused-variable member-ordering */

module API.Client {
    'use strict';

    export class LocationApi {
        private basePath = 'http://check-aurora-api.herokuapp.com';

        static $inject: string[] = ['$http', '$httpParamSerializer'];

        constructor(private $http: ng.IHttpService, basePath?: string, private $httpParamSerializer?: (any) => any) {
            if (basePath) {
                this.basePath = basePath;
            }
        }

        public locationGet (extraHttpRequestParams?: any ) : ng.IHttpPromise<{}> {
            var path = this.basePath + '/location';

            var queryParameters: any = {};
            var headerParams: any = {};
            var httpRequestParams: any = {
                method: 'GET',
                url: path,
                json: true,
                
                
                params: queryParameters,
                headers: headerParams
            };

            if (extraHttpRequestParams) {
                for (var k in extraHttpRequestParams) {
                    if (extraHttpRequestParams.hasOwnProperty(k)) {
                        httpRequestParams[k] = extraHttpRequestParams[k];
                    }
                }
            }

            return this.$http(httpRequestParams);
        }

        public updateLocation (deviceId: string, deviceType: string, lat: number, lng: number, extraHttpRequestParams?: any ) : ng.IHttpPromise<{}> {
            var path = this.basePath + '/location';

            var queryParameters: any = {};
            var headerParams: any = {};
            // verify required parameter 'deviceId' is set
            if (!deviceId) {
                throw new Error('Missing required parameter deviceId when calling updateLocation');
            }

            // verify required parameter 'deviceType' is set
            if (!deviceType) {
                throw new Error('Missing required parameter deviceType when calling updateLocation');
            }

            // verify required parameter 'lat' is set
            if (!lat) {
                throw new Error('Missing required parameter lat when calling updateLocation');
            }

            // verify required parameter 'lng' is set
            if (!lng) {
                throw new Error('Missing required parameter lng when calling updateLocation');
            }

            if (deviceId !== undefined) {
                queryParameters['deviceId'] = deviceId;
            }

            if (deviceType !== undefined) {
                queryParameters['deviceType'] = deviceType;
            }

            if (lat !== undefined) {
                queryParameters['lat'] = lat;
            }

            if (lng !== undefined) {
                queryParameters['lng'] = lng;
            }

            var httpRequestParams: any = {
                method: 'POST',
                url: path,
                json: true,
                
                
                params: queryParameters,
                headers: headerParams
            };

            if (extraHttpRequestParams) {
                for (var k in extraHttpRequestParams) {
                    if (extraHttpRequestParams.hasOwnProperty(k)) {
                        httpRequestParams[k] = extraHttpRequestParams[k];
                    }
                }
            }

            return this.$http(httpRequestParams);
        }
    }
}
