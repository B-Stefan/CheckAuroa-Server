/// <reference path="api.d.ts" />

/* tslint:disable:no-unused-variable member-ordering */

module API.Client {
    'use strict';

    export class KPIndexApi {
        private basePath = 'http://check-aurora-api.herokuapp.com';

        static $inject: string[] = ['$http', '$httpParamSerializer'];

        constructor(private $http: ng.IHttpService, basePath?: string, private $httpParamSerializer?: (any) => any) {
            if (basePath) {
                this.basePath = basePath;
            }
        }

        public getKpIndex (uTCDateTime?: string, extraHttpRequestParams?: any ) : ng.IHttpPromise<Array<KpInformation>> {
            var path = this.basePath + '/kpIndex';

            var queryParameters: any = {};
            var headerParams: any = {};
            if (uTCDateTime !== undefined) {
                queryParameters['UTCDateTime'] = uTCDateTime;
            }

            var httpRequestParams: any = {
                method: 'GET',
                url: path,
                json: true,
                
                
                params: queryParameters,
                headers: headerParams
            };

            if (extraHttpRequestParams) {
                for (var k in extraHttpRequestParams) {
                    if (extraHttpRequestParams.hasOwnProperty(k)) {
                        httpRequestParams[k] = extraHttpRequestParams[k];
                    }
                }
            }

            return this.$http(httpRequestParams);
        }

        public getLastKpIndex (uTCDateTime?: string, extraHttpRequestParams?: any ) : ng.IHttpPromise<KpInformation> {
            var path = this.basePath + '/kpIndex/last';

            var queryParameters: any = {};
            var headerParams: any = {};
            if (uTCDateTime !== undefined) {
                queryParameters['UTCDateTime'] = uTCDateTime;
            }

            var httpRequestParams: any = {
                method: 'GET',
                url: path,
                json: true,
                
                
                params: queryParameters,
                headers: headerParams
            };

            if (extraHttpRequestParams) {
                for (var k in extraHttpRequestParams) {
                    if (extraHttpRequestParams.hasOwnProperty(k)) {
                        httpRequestParams[k] = extraHttpRequestParams[k];
                    }
                }
            }

            return this.$http(httpRequestParams);
        }
    }
}
