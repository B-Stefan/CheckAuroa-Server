/// <reference path="OK.ts" />
/// <reference path="Error.ts" />
/// <reference path="Location.ts" />
/// <reference path="GeomagnaticLocation.ts" />
/// <reference path="KpInformation.ts" />
/// <reference path="WeatherInformation.ts" />
/// <reference path="Rating.ts" />
/// <reference path="Notification.ts" />

/// <reference path="KPIndexApi.ts" />
/// <reference path="NotifyApi.ts" />
/// <reference path="LocationApi.ts" />
/// <reference path="RatingsApi.ts" />
