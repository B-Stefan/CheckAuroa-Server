/// <reference path="api.d.ts" />

/* tslint:disable:no-unused-variable member-ordering */

module API.Client {
    'use strict';

    export class RatingsApi {
        private basePath = 'http://check-aurora-api.herokuapp.com';

        static $inject: string[] = ['$http', '$httpParamSerializer'];

        constructor(private $http: ng.IHttpService, basePath?: string, private $httpParamSerializer?: (any) => any) {
            if (basePath) {
                this.basePath = basePath;
            }
        }

        public getRating (lng: number, lat: number, uTCDateTime?: string, extraHttpRequestParams?: any ) : ng.IHttpPromise<Array<Rating>> {
            var path = this.basePath + '/ratings';

            var queryParameters: any = {};
            var headerParams: any = {};
            // verify required parameter 'lng' is set
            if (!lng) {
                throw new Error('Missing required parameter lng when calling getRating');
            }

            // verify required parameter 'lat' is set
            if (!lat) {
                throw new Error('Missing required parameter lat when calling getRating');
            }

            if (lng !== undefined) {
                queryParameters['lng'] = lng;
            }

            if (lat !== undefined) {
                queryParameters['lat'] = lat;
            }

            if (uTCDateTime !== undefined) {
                queryParameters['UTCDateTime'] = uTCDateTime;
            }

            var httpRequestParams: any = {
                method: 'GET',
                url: path,
                json: true,
                
                
                params: queryParameters,
                headers: headerParams
            };

            if (extraHttpRequestParams) {
                for (var k in extraHttpRequestParams) {
                    if (extraHttpRequestParams.hasOwnProperty(k)) {
                        httpRequestParams[k] = extraHttpRequestParams[k];
                    }
                }
            }

            return this.$http(httpRequestParams);
        }
    }
}
