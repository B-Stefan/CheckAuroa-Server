package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;
import io.swagger.client.Pair;

import io.swagger.client.model.*;

import java.util.*;


import org.apache.http.HttpEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;

import java.util.Map;
import java.util.HashMap;
import java.io.File;

public class LocationApi {
  String basePath = "http://check-aurora-api.herokuapp.com";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public void addHeader(String key, String value) {
    getInvoker().addDefaultHeader(key, value);
  }

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * geth the location
   * 
   * @return void
   */
  public void  locationGet () throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/location".replaceAll("\\{format\\}","json");

    // query params
    List<Pair> queryParams = new ArrayList<Pair>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return ;
      }
      else {
        return ;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * Updates the location for a spesific device
   * 
   * @param deviceId An id for your individual device
   * @param deviceType The device type code it can be on of [ANDOID, WEB, QT]
   * @param lat The lat lng position for calculate the rating
   * @param lng The lat lng position for calculate the rating
   * @return void
   */
  public void  updateLocation (String deviceId, String deviceType, Double lat, Double lng) throws ApiException {
    Object postBody = null;
    
    // verify the required parameter 'deviceId' is set
    if (deviceId == null) {
       throw new ApiException(400, "Missing the required parameter 'deviceId' when calling updateLocation");
    }
    
    // verify the required parameter 'deviceType' is set
    if (deviceType == null) {
       throw new ApiException(400, "Missing the required parameter 'deviceType' when calling updateLocation");
    }
    
    // verify the required parameter 'lat' is set
    if (lat == null) {
       throw new ApiException(400, "Missing the required parameter 'lat' when calling updateLocation");
    }
    
    // verify the required parameter 'lng' is set
    if (lng == null) {
       throw new ApiException(400, "Missing the required parameter 'lng' when calling updateLocation");
    }
    

    // create path and map variables
    String path = "/location".replaceAll("\\{format\\}","json");

    // query params
    List<Pair> queryParams = new ArrayList<Pair>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    
    queryParams.addAll(ApiInvoker.parameterToPairs("", "deviceId", deviceId));
    
    queryParams.addAll(ApiInvoker.parameterToPairs("", "deviceType", deviceType));
    
    queryParams.addAll(ApiInvoker.parameterToPairs("", "lat", lat));
    
    queryParams.addAll(ApiInvoker.parameterToPairs("", "lng", lng));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return ;
      }
      else {
        return ;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
