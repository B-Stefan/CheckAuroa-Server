package io.swagger.client.model;

import java.math.BigDecimal;
import java.util.Date;

import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


@ApiModel(description = "")
public class KpInformation  {
  
  @SerializedName("utc")
  private BigDecimal utc = null;
  @SerializedName("date")
  private Date date = null;
  @SerializedName("kpValue")
  private Double kpValue = null;

  
  /**
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getUtc() {
    return utc;
  }
  public void setUtc(BigDecimal utc) {
    this.utc = utc;
  }

  
  /**
   **/
  @ApiModelProperty(value = "")
  public Date getDate() {
    return date;
  }
  public void setDate(Date date) {
    this.date = date;
  }

  
  /**
   **/
  @ApiModelProperty(value = "")
  public Double getKpValue() {
    return kpValue;
  }
  public void setKpValue(Double kpValue) {
    this.kpValue = kpValue;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class KpInformation {\n");
    
    sb.append("  utc: ").append(utc).append("\n");
    sb.append("  date: ").append(date).append("\n");
    sb.append("  kpValue: ").append(kpValue).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
