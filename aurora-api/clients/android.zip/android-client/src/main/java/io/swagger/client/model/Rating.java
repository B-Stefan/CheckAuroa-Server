package io.swagger.client.model;

import io.swagger.client.model.GeomagnaticLocation;
import io.swagger.client.model.WeatherInformation;
import io.swagger.client.model.KpInformation;
import io.swagger.client.model.Location;

import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


@ApiModel(description = "")
public class Rating  {
  
  @SerializedName("location")
  private Location location = null;
  @SerializedName("locationGeomagnatic")
  private GeomagnaticLocation locationGeomagnatic = null;
  @SerializedName("kp")
  private KpInformation kp = null;
  @SerializedName("weather")
  private WeatherInformation weather = null;

  
  /**
   **/
  @ApiModelProperty(value = "")
  public Location getLocation() {
    return location;
  }
  public void setLocation(Location location) {
    this.location = location;
  }

  
  /**
   **/
  @ApiModelProperty(value = "")
  public GeomagnaticLocation getLocationGeomagnatic() {
    return locationGeomagnatic;
  }
  public void setLocationGeomagnatic(GeomagnaticLocation locationGeomagnatic) {
    this.locationGeomagnatic = locationGeomagnatic;
  }

  
  /**
   **/
  @ApiModelProperty(value = "")
  public KpInformation getKp() {
    return kp;
  }
  public void setKp(KpInformation kp) {
    this.kp = kp;
  }

  
  /**
   **/
  @ApiModelProperty(value = "")
  public WeatherInformation getWeather() {
    return weather;
  }
  public void setWeather(WeatherInformation weather) {
    this.weather = weather;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Rating {\n");
    
    sb.append("  location: ").append(location).append("\n");
    sb.append("  locationGeomagnatic: ").append(locationGeomagnatic).append("\n");
    sb.append("  kp: ").append(kp).append("\n");
    sb.append("  weather: ").append(weather).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
