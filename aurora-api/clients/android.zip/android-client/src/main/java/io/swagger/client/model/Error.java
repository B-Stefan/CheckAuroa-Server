package io.swagger.client.model;


import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


@ApiModel(description = "")
public class Error  {
  
  @SerializedName("msg")
  private String msg = null;
  public enum CodeEnum {
     INTERNAL,  KP_SERVICE_ERROR,  WEATHER_SERVICE_ERROR,  SUNSETRISE_SERVICE_ERROR, 
  };
  @SerializedName("code")
  private CodeEnum code = null;

  
  /**
   **/
  @ApiModelProperty(value = "")
  public String getMsg() {
    return msg;
  }
  public void setMsg(String msg) {
    this.msg = msg;
  }

  
  /**
   * The error code
   **/
  @ApiModelProperty(value = "The error code")
  public CodeEnum getCode() {
    return code;
  }
  public void setCode(CodeEnum code) {
    this.code = code;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Error {\n");
    
    sb.append("  msg: ").append(msg).append("\n");
    sb.append("  code: ").append(code).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
