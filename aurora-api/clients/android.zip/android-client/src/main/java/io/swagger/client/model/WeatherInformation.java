package io.swagger.client.model;


import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


@ApiModel(description = "")
public class WeatherInformation  {
  
  @SerializedName("summary")
  private String summary = null;

  
  /**
   **/
  @ApiModelProperty(value = "")
  public String getSummary() {
    return summary;
  }
  public void setSummary(String summary) {
    this.summary = summary;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class WeatherInformation {\n");
    
    sb.append("  summary: ").append(summary).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
