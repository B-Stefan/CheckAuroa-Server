package io.swagger.client.model;


import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


@ApiModel(description = "")
public class Notification  {
  
  @SerializedName("playSound")
  private Boolean playSound = null;

  
  /**
   **/
  @ApiModelProperty(value = "")
  public Boolean getPlaySound() {
    return playSound;
  }
  public void setPlaySound(Boolean playSound) {
    this.playSound = playSound;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Notification {\n");
    
    sb.append("  playSound: ").append(playSound).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
