package io.swagger.client.model;

import java.math.BigDecimal;

import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


@ApiModel(description = "")
public class GeomagnaticLocation  {
  
  @SerializedName("latG")
  private BigDecimal latG = null;
  @SerializedName("lngG")
  private BigDecimal lngG = null;

  
  /**
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getLatG() {
    return latG;
  }
  public void setLatG(BigDecimal latG) {
    this.latG = latG;
  }

  
  /**
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getLngG() {
    return lngG;
  }
  public void setLngG(BigDecimal lngG) {
    this.lngG = lngG;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class GeomagnaticLocation {\n");
    
    sb.append("  latG: ").append(latG).append("\n");
    sb.append("  lngG: ").append(lngG).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
